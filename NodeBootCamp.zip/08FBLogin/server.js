const express = require('express');
const passport = require('passport');
const Strategy = require('passport-facebook').Strategy;

const port = process.env.PORT || 3000;

passport.use(
    new Strategy({
        clientID: '644219102693467',
        clientSecret: '1cd5e7440271c90cb22918eb4a5b8844',
        callbackURL: 'http://localhost:3000/login/facebook/return'
    },
    function(accessToken, refreshToken, profile, cb){
        return cb(null, profile);
    }
    )
);

passport.serializeUser((user, cb)=>{
    cb(null, user);
});

passport.deserializeUser((obj, cb)=>{
    cb(null, obj);
});

//create a express app.
var app = express();

//set view dir
app.set('views', __dirname + '/views');

//set view engine
app.set('view engine', 'ejs');

app.use(require('morgan')('combined'));
app.use(require('cookie-parser')());
app.use(require('body-parser').urlencoded({extended: true}));
app.use(require('express-session')({secret: 'MVcoding App', resave: true, saveUninitialized: true}));

//@route  - GET /
// @desc  - a route to home page
// @acces - PUBLIC
app.get('/', (req, res)=>{
    res.render('home', {user : req.user});
});

//@route  - GET / LOGIN
// @desc  - a route to LOGIN page
// @acces - PUBLIC
app.get('/login', (req, res)=>{
    res.render('login');
});

//@route  - GET /login/facebook
// @desc  - a route to facebook authentication
// @acces - PUBLIC
app.get('/login/facebook', passport.authenticate('facebook'));

//@route  - GET /login/facebook/callback
// @desc  - a route to facebook authentication
// @acces - PUBLIC
app.get('/login/facebook/callback', passport.authenticate('facebook', {failureRedirect: '/login'}),
    (req, res)=>{
        //succesfully authencticate then redirect to home page.
        res.redirect('/');
    }
);

//@route  - GET /profile
// @desc  - a route to profile of user.
// @acces - PRIVATE
app.get('/profile', require('connect-ensure-login').ensureLoggedIn(),
    (req,res)=>{
        res.render('profile', {user: req.user});
    }
);

app.listen(port , ()=>console.log('server is running port 3000...'));
