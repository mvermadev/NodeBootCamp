const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const passport = require('passport');

//Load Person model 
const Person = require('../../modals/Person');

//Load Profile Model
const Profile = require('../../modals/Profile');

//Load Question Model
const Question = require('../../modals/Question');  


// type - GET
// route - /api/question
// desc - route for showing all question. 
// access - public
router.get('/', (req, res)=>{
    Question.find()
    .sort({date: 'desc'})
    .then(questions=>res.json(questions))
    .catch(err=>res.json({noQuestion: 'No question will be display'}));
});


// type - POST
// route - /api/question
// desc - route for submitting question. 
// access - PRIVATE
router.post('/', passport.authenticate('jwt', {session: false}), (req, res)=>{
    const newQuestion = new Question({
        textone: req.body.textone,
        texttwo: req.body.texttwo,
        user: req.user.id,
        name: req.body.name
    });
    newQuestion
    .save()  
    .then(question=>res.json(question))
    .catch(err=>console.log(err));
});

// type - POST
// route - /api/answer/:id
// desc - route for submitting answer to question. 
// access - PRIVATE
router.post('/answer/:id', passport.authenticate('jwt', {session: false}), (req, res)=>{
    Question.findById(req.params.id)
    .then(question=>{
        if(!question){
            return res.status(400).json({answer: 'Error to submit question'})
        }
        const newAnswer = {
            user: req.user.id,
            name: req.body.name,
            text: req.body.text
        };
        question.answer.unshift(newAnswer); // or you can use push instead of unshift
        question.save()
        .then(question=>res.json(question))
        .catch(err=>console.log(err));
    })
    .catch(err=>console.log(err));
})

// type - POST
// route - /api/upvotes/:id
// desc - route for upvotes to answers. 
// access - PRIVATE
router.post('/upvotes/:id', passport.authenticate('jwt', {session: false}), (req, res)=>{
    Profile.findOne({user: req.user.id})
    .then(profile=>{
        if(!profile){
            return res.status(400).json({upvotes: 'Error to upvotes on answer'});
        }
        Question.findById(req.params.id)
        .then(question=>{
            if(question.upvotes.filter(upvote => upvote.user.toString() === req.user.id.toString()).length > 0){
                return res.status(400).json({AlreadyUpvote: 'User has already upvoted'});
            }
            question.upvotes.unshift({user: req.user.id});
            question.save()
            .then(question=>res.json(question))
            .catch(err=>console.log(err));
        })
        .catch(err=>console.log(err))
    })
    .catch(err=>console.log(err))
});

router.delete('/Qdelete/:_id', passport.authenticate('jwt', {session: false}), (req, res)=>{
    Profile.findOne({user : req.user.id})
    Question.findOneAndRemove({user : req.user.id})
    .then(()=>{
      Question.findOneAndRemove({_id: req.params._id})
      .then(()=>res.json({QDelete: 'Questions is deleted'}))
      .catch(err=>console.log(err));
    })
    .catch(err=>console.log(err));
})

router.delete('/QdeleteAll/', passport.authenticate('jwt', {session: false}), (req, res)=>{ 
    Profile.findOne({user: req.user.id})
    .then(()=>{
        // Profile.findOne({_id: req.params._id});
        Question.find()
        .then(()=>res.json({QDeleteAll: 'All questions deleted'}))
        .catch(err=>console.log(err))
    })
    .catch(err=>console.log(err));
})

module.exports = router;

//Assignment - remove upvoting -> Pending
// Delete questions -> Done!
//Delete all question 

//Create a separate route for linux question