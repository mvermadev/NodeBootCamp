const express = require('express');
const bodyParser = require('body-parser');

let app = express();

//middleware for bodyParser.
app.use(bodyParser.urlencoded({extended: false}))

//middleware for express;
app.use('/login', express.static(__dirname + '/public'));

app.get('/', (req, res)=>{
    res.send('This is my application');
});

app.post('/login', (req, res)=>{
    console.log(req.body);
    // do some databases process;
    res.redirect('/');
})

app.listen(3000, ()=>console.log('server is runnig at port 3000...'));