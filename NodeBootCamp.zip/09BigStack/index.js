const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const passport = require('passport');

//Bring all routes:
const auth = require('./routes/api/auth');
const profile = require('./routes/api/profile');
const questions = require('./routes/api/questions');


const port = process.env.PORT || 3000;

const app = express();

//Middleware for bodyParser
app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());

//mongoDB configuration
const db = require('./setup/myurl').mongoURL

mongoose
    .connect(db)
    .then(()=>console.log('MongoDB connected succesfully'))
    .catch(err=>console.log(err));    
    
// Just for testing routes:
app.get('/', (req, res)=>{
    res.send('hello world there');
});
    
//passport middleware:
app.use(passport.initialize());

//Config for JWT strategy 
require('./strategies/jsonwtStrategy')(passport);

//actual routes
app.use('/api/auth', auth);

//routes for profile
app.use('/api/profile', profile);

//routes for questions
app.use('/api/questions', questions);

app.listen(port, ()=>console.log('server is running port 3000...'));