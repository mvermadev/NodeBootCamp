const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const passport = require('passport');

//Load Person model 
const Person = require('../../modals/Person');

//Load Profile Modal
const Profile = require('../../modals/Profile');

// type - POST
// route - /api/auth/Login
// desc - route for personal user profile. 
// access - public
router.get('/', passport.authenticate('jwt', {session : false}), (req, res)=>{
    Profile.findOne({user: req.user.id})
    .then(profile=>{
        if(!profile){
            return res.status(400).json({profile: "USer profile was not found"});
        }
        else{
            res.json(profile);
        }
    })
    .catch(err=>console.log('Got some error in profile '+err));
})

// type - POST
// route - /api/auth/Login
// desc - route for UPDATING/SAVING personnal user profile. 
// access - PRIVATE
router.post('/', passport.authenticate('jwt', {session: false}), (req, res)=>{
     const profileValues = {};
     profileValues.user = req.user.id;
     if(req.body.username) profileValues.username = req.body.username;
     if(req.body.website) profileValues.website = req.body.website;
     if(req.body.country) profileValues.country = req.body.country;
     if(req.body.portfolio) profileValues.portfolio = req.body.portfolio;
     if(typeof req.body.languages !== undefined){
         profileValues.languages = req.body.languages.split(',');
        }
        //API of social
        profileValues.social = {}
    
     if(req.body.youtube) profileValues.social.youtube = req.body.youtube;
     if(req.body.facebook) profileValues.social.facebook = req.body.facebook;
     if(req.body.Instagram) profileValues.social.Instagram = req.body.Instagram;

     // DB stuff for saving updated data.
     Profile.findOne({user: req.user.id})
     .then(profile=>{
         if(profile){
             Profile.findOneAndUpdate(
                 {user: req.user.id},
                 {$set : profileValues}, {new : true})
                 .then(profile=> res.json({profile}))
                 .catch(err=>console.log('prblem in update ' + err));
         }
         else{
             Profile.findOne({username: profileValues.username})
            //  username already exists
             .then(profile=>{
                if(profile){ 
                return res.status(400).json({username: "username already exists"}); 
                }
                new Profile(profileValues)
                .save()
                .then(profile=>{
                    return res.json(profile);
                })
                .catch(err=>console.log(err));
            })
             .catch(err=>console.log(err));
         }
     })
     .catch(err=>console.log('PRoblem in saving profile data ' + err));
    });

// type - GET
// route - /api/profile/:username
// desc - route for getting user profile base on username. 
// access - public
router.get('/withuser/:username', (req, res)=>{
    Profile.findOne({username: req.params.username})
    .populate('user', ['name', 'profilepic'])
    .then(profile=>{
        if(!profile){
            return res.status(400).json({usernotFound: 'USer not found' });
        }
        res.json(profile);
    })
    .catch(err=>console.log("Error in fetching username "+err));   
});

// type - GET
// route - /api/profile/:id
// desc - route for getting user profile base on id. 
// access - public
router.get('/withid/:_id', (req, res)=>{
    Profile.findOne({_id: req.params._id})
    .populate('user', ['name', 'profilepic'])
    .then(profile=>{
        if(!profile){
            return res.status(400).json({idNotFound: 'Id not found'});
        }
        res.json(profile);
    })
    .catch(err=>console.log('Erro in fetching id ' + err ));
});

// type - GET
// route - /api/profile/everyone
// desc - route for getting user profile of Everyone. 
// access - public
router.get('/everyone', (req,res)=>{
    Profile.find()
    .populate('user', ['name', 'profilepic'])
    .then(profiles=>{
        if(!profiles){
            return res.status(400).json({EveryoneNotFound : 'EveryOne was not found'});
        }
        res.json(profiles);
    })
    .catch(err=>console.log('Error in fetching everyone' + err));
})

// type - DELEYE
// route - /api/profile/
// desc -  deleting user based on ID. 
// access - PRIVATE
router.delete('/', passport.authenticate('jwt', {session: false}), (req, res)=>{
    Profile.findOne({ user: req.user.id});
    Profile.findOneAndRemove({user: req.user.id})
    .then( ()=>{
        Person.findOneAndRemove({_id: req.user._id})
        .then(()=>res.json({succes: 'delete successfully'}))
        .catch(err=>console.log(log));
    } )
    .catch(err=>console.log(err))
})

// type - POST
// route - /api/profile/workrole
// desc -  routed for adding work profile of a person. 
// access - PRIVATE
router.post(
    "/workrole",
    passport.authenticate("jwt", { session: false }),
    (req, res) => {
      Profile.findOne({ user: req.user.id })
        .then(profile => {
          //assignment
          if(!profile){
              return res.status(400).json({workroleError: 'ID not found'});
          }
          const newWork = {
            role: req.body.role,
            company: req.body.company,
            country: req.body.country,
            from: req.body.from,
            to: req.body.to,
            current: req.body.current,
            details: req.body.details
          };
          profile.workrole.unshift(newWork);
          profile
            .save()
            .then(profile => res.json(profile))
            .catch(err => console.log(err));
        })
        .catch(err => console.log(err));
    }
  );


// type - DELETE
// route - /api/profile/workrole/:w_id
// desc -  routed for deleting the specific workrole based on w_id. 
// access - PRIVATE
router.delete('/workrole/:w_id', passport.authenticate('jwt', {session: false}), (req, res)=>{
    Profile.findOne({user: req.user.id })
    .then(profile=>{
        if(!profile){
        return res.status(400).json({workroleError: 'Enter Id was not found in DB'});      
    }
        const removethis = profile.workrole.map(item=>item.id).indexOf(req.params.w_id);

        profile.workrole.splice(removethis, 1)
        profile.save().then(()=>res.json(profile)).catch(err=>console.log(err));
    })
    .catch(err=>console.log(err));
})

// type - GET
// route - /api/profile/questions
// desc -  routed for write questions. 
// access - PUBLIC
router.post(
    "/questions",
    passport.authenticate("jwt", { session: false }),
    (req, res) => {
      Profile.findOne({ user: req.user.id })
        .then(profile => {
          //assignment
          if(!profile){
              return res.status(400).json({questions: 'Error to submit question'});
          }
          const newQuestion= {
            textone: req.body.textone,
            texttwo: req.body.texttwo
        };
          profile.questions.unshift(newQuestion);
          profile
            .save()
            .then(profile => res.json(profile))
            .catch(err => console.log(err));
        })
        .catch(err => console.log(err));
    }
  );

module.exports = router;
