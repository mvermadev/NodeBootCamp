const express = require('express');
const router = express.Router();

router.get('/', (req, res)=>{
    res.json({questions: 'Questions is work successfully'});
});

module.exports = router;