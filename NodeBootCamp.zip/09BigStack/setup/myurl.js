module.exports = {
    mongoURL : 'mongodb+srv://manish:m-o-n-u1997mb@nodecourse-zp7aq.mongodb.net/test?retryWrites=true',
    secret: 'myStrongSecret'
};

