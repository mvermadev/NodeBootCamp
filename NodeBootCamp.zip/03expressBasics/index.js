const express = require('express');
const app = express();

app.get('/', (req, res)=>{
    res.send('Hello Manish');
}).get('/about', (req, res)=>{
    // res.send('<h1 style="color:dodgerblue; font-size: 20px; ">This is about</h1>');  
    res.status(200).json({user: 'Manish', balance :'10000', id:'1230'});
}).get('/contact', (req, res)=>{
    res.send('<h1 style="color:dodgerblue; font-size: 20px; ">Contact at manishverma@coding.com</h1>');
}).get('/services', (req, res)=>{
    res.send(`<ul>
        <li> Web development</li>
        <li> Logo Design</li>
        <li> Video creation</li>
    </ul>`);
}).get('/ab*cd', (req, res)=>{
    res.send('This is regex page');
}).get('/user/:id', (req, res)=>{
    res.send(req.params);
});

app.get('/user:id/status:status_id', (req, res)=>{
    res.send(req.params);
});
app.get('/flight/:from-:to', (req, res)=>{
    res.send(req.params);
});

app.post('/login', (req, res)=>{
    res.send('login suceess');
});

app.delete('/', (req, res)=>{
    res.send('delete request to homepage.');
    console.log('delete request to homepage');
});


app.listen(3000,()=>console.log('Server is running a prot 3000...'));


