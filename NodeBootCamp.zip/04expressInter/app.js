const express = require('express');
const app = express();

var myconsolelog = (req, res, next)=>{
    console.log('I am a middleware.');
    next();
}

var serverTime = (req, res, next)=>{
    req.requestTime = Date.now();
    next();
}

app.use(serverTime);

app.get('/', (req, res)=>{
    res.send('Hello Manish  ' + 'and time is : ' + req.requestTime);
    console.log('hello world from me');
    
});

app.listen(3000,()=>console.log('Server is running a prot 3000...'));